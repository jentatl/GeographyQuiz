package edu.uga.cs.geographyquiz;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class PastResultsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_past_results);
    }
}

